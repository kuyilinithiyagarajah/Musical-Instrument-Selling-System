package org.example.musicalinstrumentsystem;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MusicalInstrumentSystemApplication {

    public static void main(String[] args) {
        SpringApplication.run(MusicalInstrumentSystemApplication.class, args);
    }
}